import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  
  {path:"",redirectTo:"prod",pathMatch:"full"},
  {path:"prod",loadChildren:()=>import("./inventory/inventory.module").then(dt=>dt.InventoryModule)},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
