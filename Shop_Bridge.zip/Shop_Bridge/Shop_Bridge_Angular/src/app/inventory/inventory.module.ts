import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product/product.component';
import { MatInputModule} from '@angular/material/input';
import { MatSelectModule} from '@angular/material/select';
import { MatButtonModule} from '@angular/material/button';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { ProductShowpageComponent } from './product-showpage/product-showpage.component';





var routes:Routes=[ 
  {path:'',component:ProductComponent,children:[
  {path:'inventory',component:ProductShowpageComponent}
  ]
   },  
  
];
@NgModule({
  declarations: [ProductComponent, ProductShowpageComponent],
  imports: [
    CommonModule,MatInputModule,MatSelectModule,MatButtonModule,RouterModule.forChild(routes),CommonModule,ReactiveFormsModule,FormsModule,
  ]
})
export class InventoryModule { }
