import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductShowpageComponent } from './product-showpage.component';

describe('ProductShowpageComponent', () => {
  let component: ProductShowpageComponent;
  let fixture: ComponentFixture<ProductShowpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductShowpageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductShowpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
