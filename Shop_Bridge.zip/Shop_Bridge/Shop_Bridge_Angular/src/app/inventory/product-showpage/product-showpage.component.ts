import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {ProductService} from '../services/product.service'




@Component({
  selector: 'app-product-showpage',
  templateUrl: './product-showpage.component.html',
  styleUrls: ['./product-showpage.component.scss']
})
export class ProductShowpageComponent  {
  cartData:any=[];
cart_count:any;
 oldprod:any
  constructor(private rt:Router,private productser:ProductService)
   {
   this.getData()
 }


 getData(){
      
  this.productser.productApiServices().getProducts()
  .subscribe((data)=>{
   alert(data)
  }); 
  
}

  removeProd(id){
      let ob={
        id:id
         };
         this.productser.productApiServices().removeProducts(id)
         .subscribe((data)=>{this.getData()          
          });
          
    
  }
 

 

}
  

  


