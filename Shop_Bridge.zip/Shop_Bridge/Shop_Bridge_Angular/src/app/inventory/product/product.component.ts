import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup, ValidationErrors, Validators} from "@angular/forms"
import { environment } from 'src/environments/environment';
import {ActivatedRoute} from "@angular/router"
import {ProductService} from '../services/product.service'

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})


export class ProductComponent {
  imgParam:[];
  productForm:FormGroup;
    constructor(private ar:ActivatedRoute,private fb:FormBuilder,private ser:ProductService) {
    ar.params.subscribe(dt=>{
     var originalString = dt.names; 
     if(dt.names)
     {
     this.imgParam= originalString.split(','); 
     alert("sub exec...")
    
    }
    })    
      this.productForm=this.fb.group({
        "Productname":["",[Validators.required,Validators.minLength(5)]],
        "Price":["",[Validators.required,Validators.pattern("[0-9]*"),]],
        "Description":[""],
      })
     }
    ngOnInit(): void {
   
   
    }
 
  
  /////////To submit form
  submitForm=()=>{
    //console.log(this.errors)
    if(this.productForm.invalid)
    {
      var obj={errors:{}}
      Object.keys(this.productForm.controls).forEach((key)=>{
        const controlErrors:ValidationErrors=
        this.productForm.get(key).errors;
        if(controlErrors != null){
            Object.keys(controlErrors).forEach(errorMessage=>{
          })
        }
      })
      console.log(obj)
    }
    else{
      alert("hi")  
      var object={
        productName:this.productForm.controls.Productname.value,
        productDescription:this.productForm.controls.Description.value,
        price:this.productForm.controls.Price.value
        
       };  
        this.ser.productApiServices().postInsertProducts(object)
        .subscribe((data)=>{
         alert(data)
        });    
     }
   }
  }
  
