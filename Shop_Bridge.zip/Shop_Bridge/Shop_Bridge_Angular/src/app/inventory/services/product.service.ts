import { Injectable } from '@angular/core';
import{HttpClient} from "@angular/common/http"
import { Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private htClient:HttpClient) { }

  public productApiServices(){
    return{         
      postInsertProducts:(req_body):Observable<any>=>{
        alert(req_body)
        return this.htClient.post('http://localhost:8080/api/v1/products',req_body)           
      } ,

      getProducts:():Observable<any>=>{
        return this.htClient.get('http://localhost:8080/api/v1/products')           
      },
      removeProducts:(id):Observable<any>=>{
        return this.htClient.delete(`http://localhost:8080/api/v1/products/${id}`)           
      }
    }  
      
      }
}
