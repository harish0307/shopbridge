package com.shopbridge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopbridge.dao.ProductDAO;
import com.shopbridge.exception.ResourceNotFoundException;
import com.shopbridge.model.Product;
import com.shopbridge.repository.ProductRepository;
import com.shopbridge.service.ProductService;


@RestController
@RequestMapping("/api/v1")
public class ProductController {
	
    //private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static Logger LOGGER = LogManager.getLogger(ProductController.class);
  
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired ProductService productservice;
    
    @GetMapping("/products")
    public List < Product > getAllproducts() throws Exception {
    	
       List<Product>  product =productservice.getProductsList();
       
       if (product.isEmpty()) {
           throw new Exception("Currently no Product is present in database");
       } else {
           return product;
       }
       
    }

    @GetMapping("/products/{id}")
    public ResponseEntity < Product > getProductById(@PathVariable(value = "id") Long ProductId)
    throws ResourceNotFoundException {
        Product product = productRepository.findById(ProductId)
            .orElseThrow(() -> new ResourceNotFoundException("Product not found for this id :: " + ProductId));
        return ResponseEntity.ok().body(product);
    }

    @PostMapping("/products")
    public Product createProduct(@Valid @RequestBody Product product) {
        return productRepository.save(product);
       
    }
    @PutMapping("/products/{id}")
    public ResponseEntity < Product > updateProduct(@PathVariable(value = "id") Long ProductId,
        @Valid @RequestBody Product productDetails) throws ResourceNotFoundException {
        Product product = productRepository.findById(ProductId)
            .orElseThrow(() -> new ResourceNotFoundException("Product not found for this id :: " + ProductId));

        product.setPrice(productDetails.getprice());
        product.setproductDescription(productDetails.getproductDescription());
        product.setproductName(productDetails.getproductName());
        final Product updatedProduct = productRepository.save(product);
        return ResponseEntity.ok(updatedProduct);
    }

    @DeleteMapping("/products/{id}")
    public Map < String, Boolean > deleteProduct(@PathVariable(value = "id") Long ProductId)
    throws ResourceNotFoundException {
        Product product = productRepository.findById(ProductId)
            .orElseThrow(() -> new ResourceNotFoundException("Product not found for this id :: " + ProductId));

        productRepository.delete(product);
        Map < String, Boolean > response = new HashMap < > ();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
}
