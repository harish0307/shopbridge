package com.shopbridge.dao;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.shopbridge.model.*;
import com.shopbridge.repository.*;
@Component
public class ProductDAO {
	@Autowired
    private ProductRepository productRepository;
	private static Logger LOGGER = LogManager.getLogger(ProductDAO.class); 
    public List < Product > getAllProducts(){
    	LOGGER.info("----getAllProducts method in ProductDAO START----");
    	List< Product > products = productRepository.findAll();
    	LOGGER.info("----ProductList size in ProductDAO : "+products.size()+"----");
    	LOGGER.info("----getAllProducts method in ProductDAO END----");
    	 return products;    	 
    }
}
