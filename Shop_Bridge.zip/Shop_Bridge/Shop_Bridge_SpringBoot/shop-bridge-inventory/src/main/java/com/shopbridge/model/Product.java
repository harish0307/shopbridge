package com.shopbridge.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employees")
public class Product {

    private long id;
    private String productName;
    private String productDescription;
    private int price;

    public Product() {

    }

    public Product(String productName, String productDescription, int price) {
        this.productName = productName;
        this.productDescription = productDescription;
        this.price = price;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "product_name", nullable = false)
    public String getproductName() {
        return productName;
    }
    public void setproductName(String productName) {
        this.productName = productName;
    }

    @Column(name = "product_description", nullable = false)
    public String getproductDescription() {
        return productDescription;
    }
    public void setproductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    @Column(name = "price", nullable = false)
    public int getprice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
}

