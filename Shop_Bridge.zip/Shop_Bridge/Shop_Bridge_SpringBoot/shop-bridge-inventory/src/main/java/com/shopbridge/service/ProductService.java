package com.shopbridge.service;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopbridge.dao.ProductDAO;
import com.shopbridge.model.Product;

@Service
public class ProductService {
	@Autowired
	
	ProductDAO empdao;
	private static Logger LOGGER = LogManager.getLogger(ProductDAO.class);

	public List<Product> getProductsList() {

		LOGGER.info("----getAllProductList method in ProductService START----");
		List<Product> products = empdao.getAllProducts();

		LOGGER.info("----getAllProductList method in ProductService END----");
		return products;
	}

}
